/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LoginScreen } from './components/LoginScreen';
import { WhatsAppBottomNav, WhatsAppTab } from './components/WhatsAppBottomNav';
import { WhatsAppChatList, WhatsAppChat } from './components/WhatsAppChatList';
import { WhatsAppChatRoom } from './components/WhatsAppChatRoom';
import { WhatsAppCallsTab } from './components/WhatsAppCallsTab';
import { WhatsAppStatusTab } from './components/WhatsAppStatusTab';
import { CallsView } from './components/CallsView';
import { MusicPlayerView } from './components/MusicPlayerView';
import { StoriesCreateView } from './components/StoriesCreateView';
import { StoryStatus } from './components/MauroProfileBanner';
import { SixSevenEasterEgg } from './components/SixSevenEasterEgg';
import { PWAInstallButton } from './components/PWAInstallButton';
import { X, Heart, Plus } from 'lucide-react';
import { playLikePop } from './utils/audio';

function WhatsAppPlusApp() {
  const { user } = useAuth();

  // Bottom Nav Tab: 'chats' | 'llamadas' | 'estados' | 'musica'
  const [currentTab, setCurrentTab] = useState<WhatsAppTab>('chats');

  // Active chat room
  const [activeChat, setActiveChat] = useState<WhatsAppChat | null>(null);

  // Active call simulator target
  const [activeCallTarget, setActiveCallTarget] = useState<{ name: string; avatar: string } | null>(null);

  // Active story viewer
  const [viewingStory, setViewingStory] = useState<StoryStatus | null>(null);
  const [storyProgress, setStoryProgress] = useState(0);

  // Story creator modal
  const [creatingStory, setCreatingStory] = useState(false);

  // Easter egg
  const [easterEggOpen, setEasterEggOpen] = useState(false);

  // Auto advance timer for story viewer
  React.useEffect(() => {
    if (!viewingStory) {
      setStoryProgress(0);
      return;
    }
    const interval = setInterval(() => {
      setStoryProgress((prev) => {
        if (prev >= 100) {
          setViewingStory(null);
          return 0;
        }
        return prev + 2.5;
      });
    }, 100);
    return () => clearInterval(interval);
  }, [viewingStory]);

  const handleStartCall = (name: string, avatar: string) => {
    setActiveCallTarget({ name, avatar });
  };

  // If user is not logged in, keep login screen
  if (!user) {
    return (
      <div className="relative min-h-screen w-full bg-[#000000] text-white selection:bg-red-600">
        <PWAInstallButton />
        <LoginScreen onLoginSuccess={() => setCurrentTab('chats')} />
      </div>
    );
  }

  return (
    <div className="relative min-h-screen w-full bg-[#000000] text-white font-sans overflow-x-hidden selection:bg-red-600">
      {/* PWA In-App Install Banner */}
      <PWAInstallButton />

      {/* Main Tab Screens */}
      <main className="w-full h-full">
        {/* 1. Chats Tab: WhatsApp chat list with Mauro profile cover & horizontal stories at top */}
        {currentTab === 'chats' && (
          <WhatsAppChatList
            onOpenChat={(chat) => setActiveChat(chat)}
            onOpenStory={(story) => {
              setViewingStory(story);
              setStoryProgress(0);
            }}
            onAddStory={() => setCreatingStory(true)}
          />
        )}

        {/* 2. Llamadas Tab: WhatsApp call history & direct call buttons */}
        {currentTab === 'llamadas' && (
          <WhatsAppCallsTab onStartCall={handleStartCall} />
        )}

        {/* 3. Estados Tab: WhatsApp status list & my status */}
        {currentTab === 'estados' && (
          <WhatsAppStatusTab
            onOpenStory={(story) => {
              setViewingStory(story);
              setStoryProgress(0);
            }}
            onAddStory={() => setCreatingStory(true)}
          />
        )}

        {/* 4. Musica Tab: Canserbero Music Player with 4 songs */}
        {currentTab === 'musica' && <MusicPlayerView />}
      </main>

      {/* WhatsApp Plus Bottom Navigation (4 Icons: Chats, Llamadas, Estados, Musica) */}
      <WhatsAppBottomNav currentTab={currentTab} onChangeTab={setCurrentTab} />

      {/* Active WhatsApp Chat Room View (Full Screen) */}
      {activeChat && (
        <WhatsAppChatRoom
          chat={activeChat}
          onBack={() => setActiveChat(null)}
          onStartCall={handleStartCall}
        />
      )}

      {/* Interactive Call Simulator (Full Screen) */}
      {activeCallTarget && (
        <CallsView
          activeCallTarget={activeCallTarget}
          onClearActiveCall={() => setActiveCallTarget(null)}
        />
      )}

      {/* Story Creator Modal */}
      {creatingStory && (
        <div className="fixed inset-0 z-50 bg-black">
          <StoriesCreateView
            onStoryPublished={() => {
              setCreatingStory(false);
              setCurrentTab('estados');
            }}
          />
          <button
            onClick={() => setCreatingStory(false)}
            className="fixed top-4 right-4 z-50 p-2 rounded-full bg-neutral-900 border border-neutral-800 text-white cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>
      )}

      {/* Fullscreen WhatsApp Status Story Viewer */}
      {viewingStory && (
        <div className="fixed inset-0 z-50 bg-black flex items-center justify-center animate-in fade-in duration-150">
          <div className="relative w-full h-full max-w-md mx-auto flex flex-col justify-between p-4 bg-gradient-to-b from-neutral-950 via-neutral-900 to-black">
            {/* Progress Bar */}
            <div className="w-full h-1 bg-neutral-800 rounded-full overflow-hidden mt-2">
              <div
                className="h-full bg-red-600 transition-all duration-100 ease-linear shadow-[0_0_8px_#ff0000]"
                style={{ width: `${storyProgress}%` }}
              />
            </div>

            {/* Header */}
            <div className="flex items-center justify-between pt-3 z-20">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-full overflow-hidden border border-red-500 p-0.5">
                  <img src={viewingStory.avatar} alt={viewingStory.name} className="w-full h-full object-cover rounded-full" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white flex items-center gap-1">
                    <span>{viewingStory.name}</span>
                    <span className="text-[9px] bg-red-600 text-white font-black px-1 rounded">6 7</span>
                  </h3>
                  <p className="text-[10px] text-neutral-400">{viewingStory.time}</p>
                </div>
              </div>

              <button
                onClick={() => setViewingStory(null)}
                className="p-1 rounded-full text-white/80 hover:text-white bg-black/40"
              >
                <X size={20} />
              </button>
            </div>

            {/* Story Content */}
            <div className="my-auto text-center space-y-4 px-6 z-10">
              <div className="inline-flex items-baseline font-black text-8xl tracking-tighter leading-none select-none drop-shadow-[0_0_40px_rgba(255,0,0,0.85)] animate-pulse">
                <span className="text-white">6</span>
                <span className="text-[#ff0000] ml-1">7</span>
              </div>

              <div className="p-4 rounded-2xl bg-black/70 border border-neutral-800 max-w-xs mx-auto text-xs text-neutral-200 leading-relaxed font-semibold">
                {viewingStory.textSnippet}
              </div>
            </div>

            {/* Reply bar */}
            <div className="flex items-center gap-2 pb-4 z-20">
              <input
                type="text"
                placeholder={`Responder a ${viewingStory.name}...`}
                className="flex-1 bg-neutral-900 border border-neutral-800 rounded-full px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
              />
              <button
                onClick={() => {
                  playLikePop();
                  setViewingStory(null);
                }}
                className="p-2.5 rounded-full bg-neutral-900 border border-neutral-800 text-red-500"
              >
                <Heart size={20} className="fill-red-500" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6 7 Easter Egg Celebration */}
      <SixSevenEasterEgg
        isOpen={easterEggOpen}
        onClose={() => setEasterEggOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <WhatsAppPlusApp />
    </AuthProvider>
  );
}
