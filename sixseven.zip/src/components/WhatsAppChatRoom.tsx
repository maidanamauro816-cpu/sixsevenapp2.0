import React, { useState } from 'react';
import {
  ArrowLeft,
  Phone,
  Video,
  MoreVertical,
  Paperclip,
  Smile,
  Mic,
  Send,
  CheckCheck,
  Play,
  Pause,
} from 'lucide-react';
import { WhatsAppChat } from './WhatsAppChatList';
import { playLikePop, playSixSevenSound, playBassDrop } from '../utils/audio';

interface Message {
  id: string;
  sender: 'me' | 'other';
  text: string;
  time: string;
  isAudio?: boolean;
}

interface WhatsAppChatRoomProps {
  chat: WhatsAppChat;
  onBack: () => void;
  onStartCall: (name: string, avatar: string) => void;
}

export const WhatsAppChatRoom: React.FC<WhatsAppChatRoomProps> = ({
  chat,
  onBack,
  onStartCall,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      sender: 'other',
      text: chat.lastMessage,
      time: chat.time,
    },
    {
      id: 'm2',
      sender: 'other',
      text: '¡El 6 7 en WhatsApp Plus es otro nivel! 6 + 1 = 67 🔥',
      time: '6:07',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [audioPlaying, setAudioPlaying] = useState(false);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    playLikePop();
    const sentText = inputText.trim();
    const newMsg: Message = {
      id: `m_${Date.now()}`,
      sender: 'me',
      text: sentText,
      time: '6:07',
    };

    setMessages((prev) => [...prev, newMsg]);
    setInputText('');

    // Simulate "Escribiendo..." then answer
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      playSixSevenSound();
      const replies = [
        '¡Totalmente hermano! 6 7 para siempre 🔥',
        '¡Anda a la pestaña de Música y escucha Es Épico de Canserbero! 🎙️',
        'W 6 7 ratio indiscutible 🐐',
        '¡El número 6 7 está dominando el mundo entero! 🚀',
      ];
      const botText = replies[Math.floor(Math.random() * replies.length)];
      setMessages((prev) => [
        ...prev,
        {
          id: `bot_${Date.now()}`,
          sender: 'other',
          text: botText,
          time: '6:07',
        },
      ]);
    }, 1400);
  };

  const handleSendVoiceNote = () => {
    playSixSevenSound();
    const voiceMsg: Message = {
      id: `voice_${Date.now()}`,
      sender: 'me',
      text: 'Nota de voz (0:07) • 6 7 Cántico',
      time: '6:07',
      isAudio: true,
    };
    setMessages((prev) => [...prev, voiceMsg]);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#000000] text-white flex flex-col justify-between max-w-md mx-auto select-none">
      {/* WhatsApp Header */}
      <header className="bg-neutral-950 border-b border-neutral-900 px-3 py-2 flex items-center justify-between z-20">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1 text-neutral-300 hover:text-white cursor-pointer">
            <ArrowLeft size={20} />
          </button>
          <div className="relative">
            <div className="w-10 h-10 rounded-full overflow-hidden border border-neutral-700">
              <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover" />
            </div>
            <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 border border-black" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-1 leading-tight">
              <span>{chat.name}</span>
              {chat.isVerified && (
                <span className="text-[9px] bg-red-600 text-white font-black px-1 rounded">6 7</span>
              )}
            </h2>
            <p className="text-[10px] text-emerald-400 font-medium">
              {isTyping ? 'escribiendo...' : 'en línea'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-neutral-300">
          <button
            onClick={() => onStartCall(chat.name, chat.avatar)}
            className="p-1 hover:text-red-500 cursor-pointer"
            title="Videollamada"
          >
            <Video size={20} />
          </button>
          <button
            onClick={() => onStartCall(chat.name, chat.avatar)}
            className="p-1 hover:text-red-500 cursor-pointer"
            title="Llamada de voz"
          >
            <Phone size={18} />
          </button>
          <button className="p-1 hover:text-white cursor-pointer" title="Opciones">
            <MoreVertical size={20} />
          </button>
        </div>
      </header>

      {/* Messages Stream with WhatsApp background */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[radial-gradient(#171717_1px,transparent_1px)] [background-size:16px_16px] bg-black">
        {/* Date pill */}
        <div className="flex justify-center my-2">
          <span className="px-3 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-[10px] font-bold text-neutral-400 uppercase tracking-wider">
            HOY • CIFRADO EXTREMO 6 7
          </span>
        </div>

        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex flex-col ${m.sender === 'me' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[82%] px-3.5 py-2 rounded-2xl text-xs leading-relaxed relative ${
                m.sender === 'me'
                  ? 'bg-red-950/90 text-white border border-red-600/50 rounded-tr-xs shadow-[0_0_12px_rgba(255,0,0,0.2)]'
                  : 'bg-neutral-900 border border-neutral-800 text-neutral-100 rounded-tl-xs'
              }`}
            >
              {m.isAudio ? (
                <div className="flex items-center gap-2.5 py-1">
                  <button
                    onClick={() => {
                      playSixSevenSound();
                      setAudioPlaying(!audioPlaying);
                    }}
                    className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center cursor-pointer shadow-md"
                  >
                    {audioPlaying ? <Pause size={14} /> : <Play size={14} className="ml-0.5" />}
                  </button>
                  <div className="flex-1">
                    <div className="w-28 h-1 bg-neutral-700 rounded-full overflow-hidden">
                      <div className="h-full bg-red-500 w-2/3" />
                    </div>
                    <span className="text-[10px] text-neutral-400 mt-1 block">0:07 • Audio 6 7</span>
                  </div>
                </div>
              ) : (
                <p>{m.text}</p>
              )}

              {/* Timestamp & double checks */}
              <div className="flex items-center justify-end gap-1 mt-1 text-[9px] text-neutral-400">
                <span>{m.time}</span>
                {m.sender === 'me' && (
                  <CheckCheck size={14} className="text-[#ff0000] shrink-0" />
                )}
              </div>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-neutral-900 border border-neutral-800 text-[11px] text-neutral-400 w-fit">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-bounce" />
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-bounce [animation-delay:0.2s]" />
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-bounce [animation-delay:0.4s]" />
            <span className="ml-1 text-[10px] font-bold text-red-400">{chat.name} está escribiendo...</span>
          </div>
        )}
      </div>

      {/* WhatsApp Input Bar */}
      <form onSubmit={handleSend} className="bg-neutral-950 border-t border-neutral-900 p-2.5 flex items-center gap-2">
        <button
          type="button"
          onClick={() => setInputText((prev) => `${prev} 6 7 🔥`)}
          className="p-1.5 text-neutral-400 hover:text-white"
        >
          <Smile size={20} />
        </button>

        <input
          type="text"
          placeholder="Mensaje..."
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          className="flex-1 bg-neutral-900 border border-neutral-800 rounded-full px-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
        />

        {inputText.trim() ? (
          <button
            type="submit"
            className="w-10 h-10 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center transition-transform active:scale-90 cursor-pointer shadow-md"
          >
            <Send size={16} />
          </button>
        ) : (
          <button
            type="button"
            onClick={handleSendVoiceNote}
            className="w-10 h-10 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center transition-transform active:scale-90 cursor-pointer shadow-md"
            title="Enviar nota de voz 6 7"
          >
            <Mic size={18} />
          </button>
        )}
      </form>
    </div>
  );
};
