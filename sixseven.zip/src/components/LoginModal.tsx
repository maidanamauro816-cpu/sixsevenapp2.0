import React, { useState, useEffect } from 'react';
import { Phone, Sparkles, ArrowRight, ShieldCheck, AlertCircle, Zap, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ConfirmationResult } from 'firebase/auth';
import { playSixSevenSound, playSuccessChime } from '../utils/audio';

interface LoginModalProps {
  isOpen: boolean;
  onClose?: () => void;
  canDismiss?: boolean;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  canDismiss = false,
}) => {
  const {
    signInWithGoogle,
    setupPhoneRecaptcha,
    sendPhoneCode,
    confirmPhoneCode,
    signInDemoKid,
  } = useAuth();

  const [mode, setMode] = useState<'options' | 'phone_number' | 'phone_verify'>('options');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) {
      setMode('options');
      setPhoneNumber('');
      setVerificationCode('');
      setErrorMessage(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleGoogleLogin = async () => {
    try {
      setLoading(true);
      setErrorMessage(null);
      playSixSevenSound();
      await signInWithGoogle();
      playSuccessChime();
      if (onClose) onClose();
    } catch (err: unknown) {
      console.error('Google Sign In failed:', err);
      const msg = err instanceof Error ? err.message : 'Google sign in was cancelled or blocked.';
      setErrorMessage(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleStartPhone = () => {
    setMode('phone_number');
    setErrorMessage(null);
  };

  const handleSendCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber || phoneNumber.trim().length < 7) {
      setErrorMessage('Please enter a valid phone number (e.g., +15556767676).');
      return;
    }

    try {
      setLoading(true);
      setErrorMessage(null);
      const appVerifier = setupPhoneRecaptcha('recaptcha-container');
      const confirmation = await sendPhoneCode(phoneNumber.trim(), appVerifier);
      setConfirmationResult(confirmation);
      setMode('phone_verify');
      playSuccessChime();
    } catch (err: unknown) {
      console.error('Phone SMS code send error:', err);
      const msg = err instanceof Error ? err.message : 'Failed to send SMS code.';
      setErrorMessage(
        msg.includes('admin') || msg.includes('disabled') || msg.includes('app-not-authorized')
          ? 'Phone Authentication is being initialized. You can also sign in with Google or use One-Click 6 7 Mode!'
          : msg
      );
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmationResult || !verificationCode || verificationCode.trim().length < 6) {
      setErrorMessage('Please enter the 6-digit SMS verification code.');
      return;
    }

    try {
      setLoading(true);
      setErrorMessage(null);
      await confirmPhoneCode(confirmationResult, verificationCode.trim());
      playSixSevenSound();
      playSuccessChime();
      if (onClose) onClose();
    } catch (err: unknown) {
      console.error('Verification code confirmation error:', err);
      setErrorMessage('Invalid SMS code. Please check and try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemoSignIn = async (name: string) => {
    try {
      setLoading(true);
      playSixSevenSound();
      await signInDemoKid(name);
      playSuccessChime();
      if (onClose) onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-sm bg-neutral-950 border border-neutral-800 rounded-2xl p-6 text-white shadow-[0_0_50px_rgba(239,68,68,0.25)] overflow-hidden">
        {/* Glow corner decorations */}
        <div className="absolute -top-16 -right-16 w-32 h-32 bg-red-600/20 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-32 h-32 bg-cyan-500/20 rounded-full blur-2xl pointer-events-none" />

        {canDismiss && onClose && (
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-neutral-400 hover:text-white rounded-full bg-neutral-900 border border-neutral-800"
          >
            <X size={18} />
          </button>
        )}

        {/* Header / Big 6 7 Branding */}
        <div className="text-center mb-6">
          <div className="inline-flex items-baseline font-black tracking-tighter leading-none select-none text-6xl drop-shadow-[0_0_25px_rgba(239,68,68,0.8)] mb-2">
            <span className="text-white">6</span>
            <span className="text-red-500 ml-1 animate-pulse">7</span>
          </div>

          <h2 className="text-xl font-extrabold tracking-tight text-white flex items-center justify-center gap-1.5">
            <span>Log in to SixSeven</span>
            <span className="text-red-500">🔥</span>
          </h2>

          <p className="text-xs text-neutral-400 mt-1 max-w-[260px] mx-auto">
            The viral TikTok-style social app for the legendary 6 7 meme. Join the hype!
          </p>

          <div className="mt-2 inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-red-950/60 border border-red-500/30 text-[11px] font-bold text-red-300">
            <Sparkles size={11} className="text-amber-400" />
            <span>67,000+ Kids Posting Right Now</span>
          </div>
        </div>

        {errorMessage && (
          <div className="mb-4 p-3 rounded-lg bg-red-950/70 border border-red-500/50 text-red-200 text-xs flex items-start gap-2">
            <AlertCircle size={16} className="shrink-0 text-red-400 mt-0.5" />
            <span className="leading-snug">{errorMessage}</span>
          </div>
        )}

        {/* Option 1: Main Provider Options */}
        {mode === 'options' && (
          <div className="space-y-3">
            {/* Continue with Google */}
            <button
              onClick={handleGoogleLogin}
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 py-3 px-4 rounded-xl bg-white hover:bg-neutral-100 text-neutral-900 font-bold text-sm transition-all active:scale-98 shadow-md disabled:opacity-50"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Continue with Google</span>
            </button>

            {/* Continue with Phone */}
            <button
              onClick={handleStartPhone}
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 py-3 px-4 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-sm border border-neutral-700 transition-all active:scale-98 disabled:opacity-50"
            >
              <Phone size={18} className="text-red-400" />
              <span>Continue with Phone (SMS code)</span>
            </button>

            {/* Divider */}
            <div className="relative my-4 flex items-center justify-center">
              <div className="w-full border-t border-neutral-800" />
              <span className="absolute bg-neutral-950 px-2 text-[10px] font-black uppercase tracking-wider text-neutral-500">
                OR QUICK TEST
              </span>
            </div>

            {/* Quick Demo Instant Mode */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleDemoSignIn('Kai_67')}
                disabled={loading}
                className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-lg bg-red-950/40 hover:bg-red-900/60 border border-red-500/30 text-red-200 text-xs font-bold transition-all active:scale-95"
              >
                <Zap size={14} className="text-red-400" />
                <span>Play as Kai 67</span>
              </button>

              <button
                onClick={() => handleDemoSignIn('MemeKing_67')}
                disabled={loading}
                className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-white text-xs font-bold transition-all active:scale-95"
              >
                <Sparkles size={14} className="text-amber-400" />
                <span>Play as MemeKing</span>
              </button>
            </div>
          </div>
        )}

        {/* Option 2: Enter Phone Number */}
        {mode === 'phone_number' && (
          <form onSubmit={handleSendCode} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                Phone Number (Include Country Code)
              </label>
              <div className="relative">
                <input
                  type="tel"
                  placeholder="+1 555 676 7676"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-4 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-red-500 transition-colors"
                  autoFocus
                />
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">
                Standard SMS rates may apply. A 6-digit code will be sent.
              </p>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm shadow-[0_0_15px_rgba(239,68,68,0.5)] transition-all active:scale-98 disabled:opacity-50"
            >
              {loading ? 'Sending SMS Code...' : 'Send 6 7 SMS Code'}
              <ArrowRight size={16} />
            </button>

            <button
              type="button"
              onClick={() => setMode('options')}
              className="w-full py-2 text-xs font-bold text-neutral-400 hover:text-white transition-colors"
            >
              Back to Sign-in Options
            </button>
          </form>
        )}

        {/* Option 3: Verify Phone SMS Code */}
        {mode === 'phone_verify' && (
          <form onSubmit={handleVerifyCode} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1.5 text-center">
                Enter the 6-Digit Code sent to {phoneNumber}
              </label>
              <input
                type="text"
                maxLength={6}
                placeholder="6 7 6 7 6 7"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value)}
                className="w-full text-center tracking-[0.5em] font-mono text-xl bg-neutral-900 border border-neutral-700 rounded-xl py-3 text-white placeholder-neutral-600 focus:outline-none focus:border-red-500 transition-colors"
                autoFocus
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm shadow-[0_0_20px_rgba(239,68,68,0.6)] transition-all active:scale-98 disabled:opacity-50"
            >
              {loading ? 'Verifying...' : 'Verify & Enter 6 7 Hype 🔥'}
            </button>

            <button
              type="button"
              onClick={() => setMode('phone_number')}
              className="w-full py-2 text-xs font-bold text-neutral-400 hover:text-white transition-colors"
            >
              Change Phone Number
            </button>
          </form>
        )}

        {/* Invisible reCAPTCHA container for Firebase Phone Auth */}
        <div id="recaptcha-container" />

        {/* Footer Info */}
        <div className="mt-6 pt-4 border-t border-neutral-800/80 flex items-center justify-center gap-2 text-[10px] text-neutral-500">
          <ShieldCheck size={14} className="text-red-400" />
          <span>Kid-friendly, safe & 100% 6 7 meme certified</span>
        </div>
      </div>
    </div>
  );
};
