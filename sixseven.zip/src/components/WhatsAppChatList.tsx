import React, { useState } from 'react';
import {
  Search,
  Camera,
  MoreVertical,
  CheckCheck,
  Pin,
  MessageSquarePlus,
  Flame,
  Volume2,
  Sparkles,
} from 'lucide-react';
import { MauroProfileBanner, StoryStatus, STORIES_WHATSAPP } from './MauroProfileBanner';
import { playSixSevenSound, playLikePop } from '../utils/audio';

export interface WhatsAppChat {
  id: string;
  name: string;
  avatar: string;
  lastMessage: string;
  time: string;
  unreadCount: number;
  isPinned?: boolean;
  isGroup?: boolean;
  isVerified?: boolean;
  isRead?: boolean;
}

export const INITIAL_WHATSAPP_CHATS: WhatsAppChat[] = [
  {
    id: 'w_mauro',
    name: 'Mauro',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    lastMessage: 'Hermano, dale play a Canserbero en la pestaña de Música 🔥',
    time: '6:07',
    unreadCount: 2,
    isPinned: true,
    isVerified: true,
  },
  {
    id: 'w_oficial',
    name: '6 7 Oficial',
    avatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
    lastMessage: '¡Actualización WhatsApp Plus 6 7 instalada con éxito!',
    time: '6:00',
    unreadCount: 1,
    isPinned: true,
    isVerified: true,
  },
  {
    id: 'w_canserbero',
    name: 'Canserbero Fans',
    avatar: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=150&auto=format&fit=crop&q=80',
    lastMessage: 'Es Épico y Maquiavélico son historia pura del rap 🎙️',
    time: 'Ayer',
    unreadCount: 0,
    isGroup: true,
    isRead: true,
  },
  {
    id: 'w_squad',
    name: 'Squad 67',
    avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80',
    lastMessage: 'Todos conectados a las 6:07 ⚡',
    time: 'Ayer',
    unreadCount: 0,
    isGroup: true,
    isRead: true,
  },
  {
    id: 'w_profe',
    name: 'Profesor de Matemáticas',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    lastMessage: '¿Por qué respondiste 6 7 en la pregunta 1 del examen? 😭',
    time: '12/10',
    unreadCount: 0,
    isRead: true,
  },
  {
    id: 'w_memegod',
    name: 'Meme God 67',
    avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80',
    lastMessage: 'El ritual del 6 7 nunca se detiene 🐐',
    time: '10/10',
    unreadCount: 0,
    isRead: true,
  },
];

interface WhatsAppChatListProps {
  onOpenChat: (chat: WhatsAppChat) => void;
  onOpenStory: (story: StoryStatus) => void;
  onAddStory: () => void;
}

export const WhatsAppChatList: React.FC<WhatsAppChatListProps> = ({
  onOpenChat,
  onOpenStory,
  onAddStory,
}) => {
  const [chats, setChats] = useState<WhatsAppChat[]>(INITIAL_WHATSAPP_CHATS);
  const [filter, setFilter] = useState<'todos' | 'no_leidos' | 'grupos'>('todos');
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearch, setShowSearch] = useState(false);

  const filteredChats = chats.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.lastMessage.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;
    if (filter === 'no_leidos') return c.unreadCount > 0;
    if (filter === 'grupos') return !!c.isGroup;
    return true;
  });

  const handleSelectChat = (chat: WhatsAppChat) => {
    playSixSevenSound();
    // Mark as read
    setChats((prev) =>
      prev.map((item) => (item.id === chat.id ? { ...item, unreadCount: 0, isRead: true } : item))
    );
    onOpenChat(chat);
  };

  return (
    <div className="w-full max-w-md mx-auto min-h-screen bg-[#000000] text-white pb-24 selection:bg-red-600">
      {/* WhatsApp Plus Header */}
      <header className="sticky top-0 z-40 bg-[#000000] border-b border-neutral-900 px-4 pt-3 pb-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-black text-white tracking-tight flex items-center gap-1.5">
              <span>SixSeven</span>
              <span className="text-[#ff0000] drop-shadow-[0_0_10px_#ff0000]">Plus</span>
            </h1>
            <span className="text-[9px] font-black bg-red-950/80 border border-red-500/50 text-red-400 px-1.5 py-0.2 rounded">
              6 7
            </span>
          </div>

          <div className="flex items-center gap-4 text-neutral-300">
            <button
              onClick={() => onAddStory()}
              className="p-1 hover:text-white cursor-pointer"
              title="Cámara"
            >
              <Camera size={20} />
            </button>
            <button
              onClick={() => setShowSearch(!showSearch)}
              className="p-1 hover:text-white cursor-pointer"
              title="Buscar"
            >
              <Search size={20} />
            </button>
            <button className="p-1 hover:text-white cursor-pointer" title="Más opciones">
              <MoreVertical size={20} />
            </button>
          </div>
        </div>

        {/* Search Bar (if active) */}
        {showSearch && (
          <div className="mt-2.5">
            <input
              type="text"
              placeholder="Buscar mensajes o chats..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500"
              autoFocus
            />
          </div>
        )}

        {/* WhatsApp Plus Filters: Todos | No leídos | Grupos */}
        <div className="flex items-center gap-2 mt-3 pt-1">
          <button
            onClick={() => setFilter('todos')}
            className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
              filter === 'todos'
                ? 'bg-red-600 text-white shadow-[0_0_8px_#ff0000]'
                : 'bg-neutral-900 text-neutral-400 hover:text-white'
            }`}
          >
            Todos
          </button>
          <button
            onClick={() => setFilter('no_leidos')}
            className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
              filter === 'no_leidos'
                ? 'bg-red-600 text-white shadow-[0_0_8px_#ff0000]'
                : 'bg-neutral-900 text-neutral-400 hover:text-white'
            }`}
          >
            No leídos
          </button>
          <button
            onClick={() => setFilter('grupos')}
            className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
              filter === 'grupos'
                ? 'bg-red-600 text-white shadow-[0_0_8px_#ff0000]'
                : 'bg-neutral-900 text-neutral-400 hover:text-white'
            }`}
          >
            Grupos
          </button>
        </div>
      </header>

      {/* TOP: Big profile picture Mauro with cover photo & horizontal stories */}
      <MauroProfileBanner onSelectStory={onOpenStory} onAddStory={onAddStory} />

      {/* MIDDLE: WhatsApp chat list with avatars and messages */}
      <div className="divide-y divide-neutral-950">
        {filteredChats.map((chat) => (
          <button
            key={chat.id}
            onClick={() => handleSelectChat(chat)}
            className="w-full flex items-center gap-3.5 px-4 py-3 hover:bg-neutral-950/80 active:bg-neutral-900 transition-colors text-left cursor-pointer group"
          >
            {/* Avatar */}
            <div className="relative shrink-0">
              <div className="w-13 h-13 rounded-full overflow-hidden border border-neutral-800 group-hover:border-red-500/70 transition-colors">
                <img src={chat.avatar} alt={chat.name} className="w-full h-full object-cover" />
              </div>
              {chat.isVerified && (
                <span className="absolute bottom-0 right-0 w-4 h-4 rounded-full bg-red-600 text-white text-[8px] font-black flex items-center justify-center border-2 border-black">
                  67
                </span>
              )}
            </div>

            {/* Chat Details */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-1.5 min-w-0">
                  <h3 className="text-sm font-bold text-white truncate">{chat.name}</h3>
                  {chat.isPinned && (
                    <Pin size={12} className="text-neutral-500 fill-neutral-500 shrink-0 rotate-45" />
                  )}
                </div>
                <span
                  className={`text-[11px] font-bold ${
                    chat.unreadCount > 0 ? 'text-[#ff0000]' : 'text-neutral-500'
                  }`}
                >
                  {chat.time}
                </span>
              </div>

              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1 text-xs text-neutral-400 truncate">
                  {/* WhatsApp Plus signature double checkmarks */}
                  {chat.isRead && (
                    <CheckCheck size={15} className="text-[#ff0000] shrink-0" />
                  )}
                  <span className="truncate">{chat.lastMessage}</span>
                </div>

                {/* Red Unread Badge */}
                {chat.unreadCount > 0 && (
                  <span className="w-5 h-5 rounded-full bg-[#ff0000] text-white text-[10px] font-black flex items-center justify-center shrink-0 shadow-[0_0_8px_#ff0000]">
                    {chat.unreadCount}
                  </span>
                )}
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Floating Action Button (FAB) in Red */}
      <button
        onClick={() => onOpenChat(chats[0])}
        className="fixed bottom-20 right-5 z-30 w-14 h-14 rounded-full bg-gradient-to-r from-red-600 to-[#ff0000] hover:from-red-500 hover:to-red-600 text-white flex items-center justify-center shadow-[0_0_20px_rgba(255,0,0,0.6)] active:scale-90 transition-transform cursor-pointer"
        title="Nuevo mensaje 6 7"
      >
        <MessageSquarePlus size={24} />
      </button>
    </div>
  );
};
