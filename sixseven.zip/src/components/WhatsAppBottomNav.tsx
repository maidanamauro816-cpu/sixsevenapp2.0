import React from 'react';
import { MessageSquare, Phone, CircleDashed, Music2 } from 'lucide-react';

export type WhatsAppTab = 'chats' | 'llamadas' | 'estados' | 'musica';

interface WhatsAppBottomNavProps {
  currentTab: WhatsAppTab;
  onChangeTab: (tab: WhatsAppTab) => void;
  unreadChatsCount?: number;
  missedCallsCount?: number;
}

export const WhatsAppBottomNav: React.FC<WhatsAppBottomNavProps> = ({
  currentTab,
  onChangeTab,
  unreadChatsCount = 3,
  missedCallsCount = 1,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#000000] border-t border-neutral-900/90 backdrop-blur-md px-3 py-1.5 pb-safe select-none">
      <div className="max-w-md mx-auto flex items-center justify-around">
        {/* 1. Chats */}
        <button
          onClick={() => onChangeTab('chats')}
          className={`relative flex flex-col items-center justify-center py-1 px-4 transition-colors cursor-pointer ${
            currentTab === 'chats' ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <div className="relative">
            <MessageSquare
              size={22}
              strokeWidth={currentTab === 'chats' ? 2.5 : 2}
              className={currentTab === 'chats' ? 'text-white drop-shadow-[0_0_8px_rgba(255,0,0,0.6)]' : ''}
            />
            {unreadChatsCount > 0 && (
              <span className="absolute -top-1 -right-2 px-1 py-0.2 bg-[#ff0000] text-white text-[9px] font-black rounded-full min-w-4 text-center leading-tight shadow-[0_0_6px_#ff0000]">
                {unreadChatsCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold mt-1 tracking-tight">Chats</span>
        </button>

        {/* 2. Llamadas */}
        <button
          onClick={() => onChangeTab('llamadas')}
          className={`relative flex flex-col items-center justify-center py-1 px-4 transition-colors cursor-pointer ${
            currentTab === 'llamadas' ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <div className="relative">
            <Phone
              size={22}
              strokeWidth={currentTab === 'llamadas' ? 2.5 : 2}
              className={currentTab === 'llamadas' ? 'text-white drop-shadow-[0_0_8px_rgba(255,0,0,0.6)]' : ''}
            />
            {missedCallsCount > 0 && (
              <span className="absolute -top-1 -right-2 px-1 py-0.2 bg-[#ff0000] text-white text-[9px] font-black rounded-full min-w-4 text-center leading-tight shadow-[0_0_6px_#ff0000]">
                {missedCallsCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold mt-1 tracking-tight">Llamadas</span>
        </button>

        {/* 3. Estados */}
        <button
          onClick={() => onChangeTab('estados')}
          className={`relative flex flex-col items-center justify-center py-1 px-4 transition-colors cursor-pointer ${
            currentTab === 'estados' ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <div className="relative">
            <CircleDashed
              size={22}
              strokeWidth={currentTab === 'estados' ? 2.5 : 2}
              className={currentTab === 'estados' ? 'text-[#ff0000] drop-shadow-[0_0_10px_#ff0000]' : ''}
            />
          </div>
          <span className="text-[10px] font-bold mt-1 tracking-tight">Estados</span>
        </button>

        {/* 4. Musica */}
        <button
          onClick={() => onChangeTab('musica')}
          className={`relative flex flex-col items-center justify-center py-1 px-4 transition-colors cursor-pointer ${
            currentTab === 'musica' ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'
          }`}
        >
          <div className="relative">
            <Music2
              size={22}
              strokeWidth={currentTab === 'musica' ? 2.5 : 2}
              className={currentTab === 'musica' ? 'text-[#ff0000] animate-bounce drop-shadow-[0_0_10px_#ff0000]' : ''}
            />
          </div>
          <span className="text-[10px] font-bold mt-1 tracking-tight">Música</span>
        </button>
      </div>
    </nav>
  );
};
