import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User as FirebaseUser,
  onAuthStateChanged,
  signInWithPopup,
  signOut as fbSignOut,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  ConfirmationResult,
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile } from '../types';

interface AuthContextType {
  user: FirebaseUser | null;
  profile: UserProfile | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  setupPhoneRecaptcha: (containerId: string) => RecaptchaVerifier;
  sendPhoneCode: (phoneNumber: string, recaptchaVerifier: RecaptchaVerifier) => Promise<ConfirmationResult>;
  confirmPhoneCode: (confirmationResult: ConfirmationResult, code: string) => Promise<void>;
  signInDemoKid: (username?: string) => Promise<void>;
  signOut: () => Promise<void>;
  boostAura67: (amount?: number) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Load or initialize Firestore profile when Firebase auth user changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const userRef = doc(db, 'users', currentUser.uid);
          const snap = await getDoc(userRef);
          if (snap.exists()) {
            setProfile(snap.data() as UserProfile);
          } else {
            // Create default profile for user
            const baseHandle = currentUser.displayName
              ? currentUser.displayName.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 15)
              : (currentUser.phoneNumber ? currentUser.phoneNumber.slice(-4) : 'sixseven');
            const cleanUsername = `${baseHandle || 'kid'}_67`;

            const newProfile: UserProfile = {
              uid: currentUser.uid,
              displayName: currentUser.displayName || (currentUser.phoneNumber ? `User ${currentUser.phoneNumber.slice(-4)}` : '6 7 Legend'),
              username: cleanUsername,
              photoURL: currentUser.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${currentUser.uid}&backgroundColor=000000`,
              bio: 'Living in 6 7 hype mode 🔥 6 7 on top!',
              score67: 670,
              followersCount: 67,
              followingCount: 6,
              createdAt: new Date().toISOString(),
            };

            await setDoc(userRef, newProfile);
            setProfile(newProfile);
          }
        } catch (err) {
          // If Firestore read fails (e.g., offline or permissions), fallback to basic local profile
          console.warn('Could not sync user profile with Firestore:', err);
          setProfile({
            uid: currentUser.uid,
            displayName: currentUser.displayName || '6 7 Legend',
            username: 'sixseven_king',
            score67: 670,
            followersCount: 67,
            followingCount: 67,
            photoURL: currentUser.photoURL || 'https://api.dicebear.com/7.x/bottts/svg?seed=67',
            bio: 'Certified 6 7 Meme Master 🐐',
          });
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Google Sign In Error:', error);
      throw error;
    }
  };

  const setupPhoneRecaptcha = (containerId: string): RecaptchaVerifier => {
    // Reset any existing instance attached to window if needed
    const win = window as unknown as { recaptchaVerifier?: RecaptchaVerifier };
    if (win.recaptchaVerifier) {
      try {
        win.recaptchaVerifier.clear();
      } catch {
        // ignore
      }
    }
    const verifier = new RecaptchaVerifier(auth, containerId, {
      size: 'invisible',
      callback: () => {
        // reCAPTCHA solved
      },
      'expired-callback': () => {
        console.warn('reCAPTCHA expired');
      },
    });
    win.recaptchaVerifier = verifier;
    return verifier;
  };

  const sendPhoneCode = async (phoneNumber: string, recaptchaVerifier: RecaptchaVerifier): Promise<ConfirmationResult> => {
    try {
      const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, recaptchaVerifier);
      return confirmationResult;
    } catch (error) {
      console.error('Phone sign in error:', error);
      throw error;
    }
  };

  const confirmPhoneCode = async (confirmationResult: ConfirmationResult, code: string) => {
    try {
      await confirmationResult.confirm(code);
    } catch (error) {
      console.error('SMS verification code error:', error);
      throw error;
    }
  };

  // Demo Kid mode allows immediate testing without phone credits / popup blockers
  const signInDemoKid = async (customName = 'ViralKid_67') => {
    const dummyUid = `kid_67_${Date.now().toString().slice(-6)}`;
    const demoProfile: UserProfile = {
      uid: dummyUid,
      displayName: customName,
      username: customName.toLowerCase(),
      photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${dummyUid}&backgroundColor=000000`,
      bio: '6 7 meme kid #1 in the world 🚀🔥',
      score67: 6767,
      followersCount: 670,
      followingCount: 67,
      createdAt: new Date().toISOString(),
    };
    // Mock user object
    const mockUser = {
      uid: dummyUid,
      displayName: demoProfile.displayName,
      email: `${demoProfile.username}@sixseven.fun`,
      emailVerified: true,
      isAnonymous: false,
      photoURL: demoProfile.photoURL,
    } as unknown as FirebaseUser;

    setUser(mockUser);
    setProfile(demoProfile);
    try {
      const userRef = doc(db, 'users', dummyUid);
      await setDoc(userRef, demoProfile);
    } catch {
      // offline or mock
    }
  };

  const signOut = async () => {
    try {
      await fbSignOut(auth);
    } catch {
      // ignore
    }
    setUser(null);
    setProfile(null);
  };

  const boostAura67 = async (amount = 67) => {
    if (!profile) return;
    const newScore = (profile.score67 || 0) + amount;
    setProfile({ ...profile, score67: newScore });

    if (user?.uid) {
      try {
        const userRef = doc(db, 'users', user.uid);
        await updateDoc(userRef, { score67: newScore });
      } catch (err) {
        // Log gracefully
        console.warn('Score update delayed:', err);
      }
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        signInWithGoogle,
        setupPhoneRecaptcha,
        sendPhoneCode,
        confirmPhoneCode,
        signInDemoKid,
        signOut,
        boostAura67,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
